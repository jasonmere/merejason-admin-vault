
# MereJason Secure Admin Portal

## 🚀 Hosting Setup (Render / Railway)

### Option 1: Deploy on Render.com
1. Create free account at https://render.com
2. Create new Web Service
3. Connect GitHub or upload ZIP
4. Add:
   - `Procfile`
   - `requirements.txt`
   - `runtime.txt`
5. Set Build Command: `pip install -r requirements.txt`
6. Set Start Command: `python app.py`

### Option 2: Deploy Locally
```bash
pip install flask werkzeug
python app.py
```

### Admin Login:
- **Username**: admin
- **Password**: password123

You can change the password inside the `users` table in `registry.db` after first run.

---

🔐 For production:
- Use `gunicorn` + `nginx` (VPS) or deploy with SSL on platforms like Render, Railway, or Heroku.
